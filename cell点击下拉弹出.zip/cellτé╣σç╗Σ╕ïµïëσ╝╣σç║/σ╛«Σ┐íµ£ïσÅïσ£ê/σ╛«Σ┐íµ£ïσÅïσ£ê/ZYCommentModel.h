//
//  ZYCommentModel.h
//  微信朋友圈
//
//  Created by 懒洋洋 on 16/9/6.
//  Copyright © 2016年 LDwl. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ZYCommentModel : NSObject
/**头像*/
@property (nonatomic,strong)NSString *avatar;
/**用户名*/
@property (nonatomic,strong)NSString *userName;
/**时间*/
@property (nonatomic,strong)NSString *timeStamp;
/**发表的文字*/
@property (nonatomic,strong)NSString *commentText;
/**发表的图片数组*/
@property (nonatomic,strong)NSArray *commentPics;
/**回答的数组*/
@property (nonatomic,strong)NSString *commentReplys;

@end
