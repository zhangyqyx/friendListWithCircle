//
//  ZYHeaderView.m
//  微信朋友圈
//
//  Created by 懒洋洋 on 16/9/7.
//  Copyright © 2016年 LDwl. All rights reserved.
//

#import "ZYHeaderView.h"
#import "UIImageView+WebCache.h"


//间隔
#define kGAP 10

@implementation ZYHeaderView


//复用
- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithReuseIdentifier:reuseIdentifier]) {
        self.avatarIV = [[UIImageView alloc] init];
        [self addSubview:self.avatarIV];
        
        self.userNameLabel = [[UILabel alloc] init];
        self.userNameLabel.numberOfLines = 0;
        self.userNameLabel.textColor = [UIColor orangeColor];
        [self addSubview:self.userNameLabel];
        
        self.timeStampLabel = [[UILabel alloc] init];
          self.timeStampLabel.numberOfLines = 0;
           self.timeStampLabel.textColor = [UIColor lightGrayColor];
        self.timeStampLabel.font = [UIFont systemFontOfSize:14];
        [self addSubview:self.timeStampLabel];
        
        self.commentTextLabel = [[UILabel alloc] init];
          self.commentTextLabel.numberOfLines = 0;
        [self addSubview:self.commentTextLabel];
        
        self.commentBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        self.commentBtn.backgroundColor = [UIColor orangeColor];
        [self.commentBtn setTitle:@"发表" forState:UIControlStateNormal];
        [self.commentBtn addTarget:self action:@selector(commentAction:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:self.commentBtn];
        
    }
    return  self;
}
- (void)commentAction:(UIButton *)commentBtn {
    
}
//初始化数据
- (void)setModel:(ZYCommentModel *)model {
    _model = model;
    //初始化各个控件的高度
    self.avatarIV.frame = CGRectMake(kGAP, kGAP, 50, 50);
    self.avatarIV.layer.cornerRadius = self.avatarIV.frame.size.width * 0.5;
    self.avatarIV.layer.masksToBounds = YES;
    self.userNameLabel.frame = CGRectMake(self.avatarIV.frame.size.width + self.avatarIV.frame.origin.x + kGAP , self.avatarIV.frame.origin.y, SCREEN_WIDTH - 2 * kGAP - self.avatarIV.frame.size.width , self.avatarIV.frame.size.height * 0.5);
    self.timeStampLabel.frame = CGRectMake(self.userNameLabel.frame.origin.x, self.userNameLabel.frame.origin.y + self.userNameLabel.frame.size.height , self.userNameLabel.frame.size.width, self.userNameLabel.frame.size.height );
    NSDictionary *attributes = @{NSFontAttributeName : [UIFont systemFontOfSize:17]};
    
    //计算发表文字的高度
    CGSize size = [model.commentText boundingRectWithSize:CGSizeMake(self.userNameLabel.frame.size.width - 2 * kGAP, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:attributes context:nil].size;
    self.commentTextLabel.frame = CGRectMake(self.userNameLabel.frame.origin.x , self.timeStampLabel.frame.origin.y + self.timeStampLabel.frame.size.height + kGAP , self.userNameLabel.frame.size.width - 2 * kGAP,size.height + 2 * kGAP);
    for (UIView *view in self.subviews) {
        if ([view isKindOfClass:[ZYJGGView class]]) {
            [view.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
            [view removeFromSuperview];
        }
    }
    //计算视图的高度
    CGFloat JGGViewHeight = 0;
    if (model.commentPics.count <=  3) {
        JGGViewHeight = ([ZYJGGView imageHeigth]+kGAP) ;
    }else if (model.commentPics.count > 3 && model.commentPics.count <= 6) {
        JGGViewHeight = ([ZYJGGView imageHeigth] + kGAP )* 2;
    }else if (model.commentPics.count > 6 && model.commentPics.count <= 9) {
        JGGViewHeight = ([ZYJGGView imageHeigth] + kGAP )* 3 ;
    }
    
    //初始化九宫格
    if (model.commentPics.count) {
        self.JGGView = [[ZYJGGView alloc] initWithFrame:CGRectMake(self.commentTextLabel.frame.origin.x, self.commentTextLabel.frame.origin.y + self.commentTextLabel.frame.size.height + kGAP, self.commentTextLabel.frame.size.width, JGGViewHeight) dataSource:model.commentPics completeBlock:^(NSInteger index, NSArray *dataSource) {
            if (self.tapBlock) {
                self.tapBlock(index , dataSource);
            }
            
            
        }];
        [self addSubview:self.JGGView];
        self.frame = CGRectMake(0, 0, SCREEN_WIDTH, kGAP + self.avatarIV.frame.size.height + kGAP + self.commentTextLabel.frame.size.height + kGAP + self.JGGView.frame.size.height + kGAP);
    }else {
          self.frame = CGRectMake(0, 0, SCREEN_WIDTH, kGAP + self.avatarIV.frame.size.height + kGAP + self.commentTextLabel.frame.size.height + kGAP );
    }
    //设置各个控件的文字
    [self.avatarIV setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:nil];
    self.userNameLabel.text = model.userName;
    self.timeStampLabel.text = model.timeStamp;
    self.commentTextLabel.text = model.commentText;
    
}

@end
