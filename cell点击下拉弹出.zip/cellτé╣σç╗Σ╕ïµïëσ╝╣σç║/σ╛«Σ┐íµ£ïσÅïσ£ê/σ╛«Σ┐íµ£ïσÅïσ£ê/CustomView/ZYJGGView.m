//
//  ZYJGGView.m
//  微信朋友圈
//
//  Created by 懒洋洋 on 16/9/9.
//  Copyright © 2016年 LDwl. All rights reserved.
//

#import "ZYJGGView.h"
#import "UIImageView+WebCache.h"

@implementation ZYJGGView

/** 初始化九宫格 */
- (instancetype)initWithFrame:(CGRect)frame dataSource:(NSArray *)dataSource completeBlock:(TapBlock)tapBlock {
    
    if (self = [super initWithFrame:frame]) {
        for (NSUInteger i = 0; i < dataSource.count; i ++) {
            UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0 + ([ZYJGGView imageWidth] + kGAP) * (i%3),  floorf(i / 3.0) * ([ZYJGGView imageHeigth] + kGAP), [ZYJGGView imageWidth], [ZYJGGView imageHeigth])];
            if ([dataSource[i] isKindOfClass:[UIImage class]]) {
                imageView.image = dataSource[i];
            }else if ([dataSource[i] isKindOfClass:[NSString class]]) {
                [imageView setImageWithURL:[NSURL URLWithString:dataSource[i]] placeholderImage:[UIImage imageNamed:@"placheholder"]];
            }else if ([dataSource[i] isKindOfClass:[NSURL class]]) {
                 [imageView setImageWithURL:dataSource[i] placeholderImage:[UIImage imageNamed:@"placheholder"]];
            }
            self.dataSource = dataSource;
            self.tapBlock = tapBlock;
            imageView.userInteractionEnabled = YES;
            imageView.tag = i;
            [self addSubview:imageView];
            UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapImageAction:)];
            [imageView addGestureRecognizer:singleTap];
            
        }
    }
    return self;
}
/** 配置图片的宽 */
+ (CGFloat)imageWidth{
    return (SCREEN_WIDTH - 5 * kGAP - 35 - 50)/3;
}

/** 配置图片的高 */
+ (CGFloat)imageHeigth {
   return (SCREEN_WIDTH - 5 * kGAP - 35 - 50)/3;
}
- (void)tapImageAction:(UITapGestureRecognizer *)tap {
    UIImageView *tapView = (UIImageView *)tap.view;
    if (self.tapBlock) {
        self.tapBlock(tapView.tag , self.dataSource);
    }
}
- (void)setDataSource:(NSArray *)dataSource {
    _dataSource = dataSource;
    [self layoutSubviews];
}
@end
