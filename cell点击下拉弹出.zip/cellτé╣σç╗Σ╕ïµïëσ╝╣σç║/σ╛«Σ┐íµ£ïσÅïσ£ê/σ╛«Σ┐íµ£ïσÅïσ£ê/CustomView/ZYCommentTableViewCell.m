//
//  ZYCommentTableViewCell.m
//  微信朋友圈
//
//  Created by 懒洋洋 on 16/9/8.
//  Copyright © 2016年 LDwl. All rights reserved.
//

#import "ZYCommentTableViewCell.h"

@implementation ZYCommentTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
