//
//  ZYJGGView.h
//  微信朋友圈
//
//  Created by 懒洋洋 on 16/9/9.
//  Copyright © 2016年 LDwl. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kGAP 10


typedef void (^TapBlock)(NSInteger index , NSArray *dataSource);

@interface ZYJGGView : UIView
/**九宫格展示数据源*/
@property (nonatomic,strong)NSArray *dataSource;
/**回调block */
@property (nonatomic,copy)TapBlock tapBlock;

/** 初始化九宫格 */
- (instancetype)initWithFrame:(CGRect)frame dataSource:(NSArray *)dataSource completeBlock:(TapBlock)tapBlock;
/** 配置图片的宽 */
+ (CGFloat)imageWidth;

/** 配置图片的高 */
+ (CGFloat)imageHeigth;

@end
