//
//  ZYHeaderView.h
//  微信朋友圈
//
//  Created by 懒洋洋 on 16/9/7.
//  Copyright © 2016年 LDwl. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZYCommentModel.h"
#import "ZYJGGView.h"

typedef void (^TapBlock)(NSInteger index , NSArray *dataSource);
@interface ZYHeaderView : UITableViewHeaderFooterView

/** 头像 */
@property (nonatomic,strong)UIImageView *avatarIV;
/** 用户名 */
@property (nonatomic,strong)UILabel *userNameLabel;
/** 时间戳 */
@property (nonatomic,strong)UILabel *timeStampLabel;
/** 发表的文字 */
@property (nonatomic,strong)UILabel *commentTextLabel;
/** 全文按钮 */
@property (nonatomic,strong)UIButton *commentBtn;
/** 模型数据 */
@property (nonatomic,strong)ZYCommentModel *model;
/** 九宫格 */
@property (nonatomic,strong)ZYJGGView *JGGView;

/**回调block */
@property (nonatomic,copy)TapBlock tapBlock;

@end
